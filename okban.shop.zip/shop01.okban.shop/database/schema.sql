-- 1. Tạo bảng CHA: Sản phẩm chung (sanpham)
CREATE TABLE IF NOT EXISTS sanpham (
    id BIGSERIAL PRIMARY KEY,                   -- ID tự tăng (Khóa chính)
    name VARCHAR(255) NOT NULL,                 -- Tên sản phẩm
    image_urls JSONB DEFAULT '[]',              -- Lưu danh sách đường dẫn ảnh (Tối đa 9 ảnh)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Tạo bảng CON: Các biến thể (sku)
CREATE TABLE IF NOT EXISTS sku (
    id BIGSERIAL PRIMARY KEY,                   -- ID tự tăng của SKU
    product_id BIGINT REFERENCES sanpham(id) ON DELETE CASCADE, -- Khóa ngoại
    sku_name VARCHAR(255) NOT NULL,             -- Tên SKU
    sku_image_url VARCHAR(500),                 -- Đường dẫn 1 ảnh đại diện
    price NUMERIC(15, 2) NOT NULL DEFAULT 0,    -- Giá
    currency VARCHAR(10) DEFAULT 'VND',         -- Đơn vị tiền tệ
    content_category VARCHAR(100),              -- Phục vụ TikTok API
    content_type VARCHAR(100) DEFAULT 'product',
    description TEXT,                           -- Mô tả chi tiết
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Index
CREATE INDEX IF NOT EXISTS idx_sku_product_id ON sku(product_id);

-- 4. Logs API
CREATE TABLE IF NOT EXISTS tiktok_checkout_logs (
    id BIGSERIAL PRIMARY KEY,
    event_name VARCHAR(50) NOT NULL CHECK (event_name IN ('InitiateCheckout', 'CompletePayment')),
    event_id VARCHAR(255) UNIQUE NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price NUMERIC(15, 2) NOT NULL DEFAULT 0,
    total_value NUMERIC(15, 2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    currency VARCHAR(10) DEFAULT 'VND',
    content_category VARCHAR(255) DEFAULT 'Thiết bị gia dụng > Dụng cụ nhà bếp > Thiết bị nhà bếp chuyên dụng',
    content_type VARCHAR(50) DEFAULT 'product',
    sku_id VARCHAR(100),
    user_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_checkout_event_id ON tiktok_checkout_logs(event_id);
