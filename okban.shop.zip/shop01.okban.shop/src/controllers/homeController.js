const db = require('../config/db');

const tiktokService = require('../services/tiktokService');

exports.index = async (req, res) => {
    try {
        // Lấy sản phẩm đầu tiên hoặc sản phẩm mặc định
        const productResult = await db.query('SELECT * FROM sanpham ORDER BY id DESC LIMIT 1');
        const product = productResult.rows[0];

        let skus = [];
        if (product) {
            const skuResult = await db.query('SELECT * FROM sku WHERE product_id = $1 ORDER BY price ASC', [product.id]);
            skus = skuResult.rows;
        }

        res.render('pages/index', { product, skus, pixelCode: process.env.TIKTOK_PIXEL_CODE });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};

exports.initiateCheckout = async (req, res) => {
    // ============================================================
    // BƯỚC 1: NHẬN DỮ LIỆU TỪ CLIENT GỬI LÊN
    // ============================================================
    const { event_id, user_data, quantity: reqQty, value: reqValue, currency, content_category, content_type } = req.body;
    const raw_id_sku = req.body.id_sku || req.body.sku_id;

    // Chuyển đổi ID SKU sang số nguyên an toàn
    let id_sku = parseInt(raw_id_sku);
    if (isNaN(id_sku)) {
        console.error('[TikTok Service] Invalid SKU ID:', raw_id_sku);
        id_sku = null; // Nếu ID lỗi thì coi như không có sản phẩm cụ thể
    }

    try {
        // ============================================================
        // BƯỚC 2: TÌM GIÁ SẢN PHẨM TỪ DATABASE (ĐỂ BẢO MẬT GIÁ)
        // ============================================================
        let price = 0;
        let contentName = 'Product';
        let sku = null;

        if (id_sku) {
            // Truy vấn vào bảng 'sku' để lấy giá gốc, tránh việc Client gian lận gửi giá lên
            const skuRes = await db.query('SELECT * FROM sku WHERE id = $1', [id_sku]);
            sku = skuRes.rows[0];

            if (!sku) {
                console.warn(`[TikTok Service] SKU Not Found for ID: ${id_sku}`);
            } else {
                // Làm sạch giá (bỏ chữ cái, chỉ lấy số)
                let rawPrice = sku.price || 0;
                if (typeof rawPrice === 'string') rawPrice = rawPrice.replace(/[^0-9.]/g, '');

                price = parseFloat(rawPrice) || 0;
                contentName = sku.sku_name || 'Product';
            }
        }

        // ============================================================
        // BƯỚC 3: TÍNH TOÁN TỔNG GIÁ TRỊ ĐƠN HÀNG (TOTAL VALUE)
        // ============================================================
        const quantity = parseInt(reqQty) || 1;
        const finalPrice = price; // Giá cuối cùng (sau khi lấy từ DB)
        const totalValue = quantity * finalPrice; // Tổng tiền = Số lượng * Đơn giá

        // Lấy IP của người dùng (quan trọng cho tracking)
        const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const enrichedUserData = { ...user_data, ip_address: clientIp };

        // ============================================================
        // BƯỚC 4: LƯU LOG VÀO DATABASE (TIKTOK_CHECKOUT_LOGS)
        // ============================================================
        const pageUrl = process.env.APP_BASE_URL || 'https://shop01.okban.shop/';
        const referrer = req.headers['referer'] || '';
        const contentId = id_sku ? id_sku.toString() : null;

        // Lấy 2 tham số quan trọng nhất của TikTok Tracking
        const ttclid = req.cookies.ttclid || req.query.ttclid || ''; // Click ID
        const ttp = req.cookies._ttp || ''; // Pixel Cookie
        const userAgent = req.headers['user-agent'] || '';

        await db.query(
            `INSERT INTO tiktok_checkout_logs 
          (event_name, event_id, quantity, unit_price, sku_id, user_data, currency, content_category, content_type, page_url, referrer, content_id, ttclid, ttp, user_agent, total_value)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
          ON CONFLICT (event_id) DO NOTHING`,
            ['InitiateCheckout', event_id, quantity, finalPrice, id_sku ? id_sku.toString() : null, enrichedUserData, currency || 'VND', content_category || '', content_type || 'product', pageUrl, referrer, contentId, ttclid, ttp, userAgent, totalValue]
        );

        // ============================================================
        // BƯỚC 5: GỬI SỰ KIỆN SANG TIKTOK API (SERVER-SIDE)
        // ============================================================
        tiktokService.sendInitiateCheckout(req, {
            id_sku: id_sku,
            price: finalPrice,
            quantity: quantity
        });

        res.json({ success: true });

    } catch (err) {
        console.error('[InitiateCheckout Error]', err);
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.completePayment = async (req, res) => {
    // ============================================================
    // BƯỚC 1: NHẬN DỮ LIỆU ĐƠN HÀNG TỪ CLIENT
    // ============================================================
    const { event_id, quantity: reqQty, user_data, value: reqValue, currency, content_category, content_type } = req.body;
    const raw_id_sku = req.body.id_sku || req.body.sku_id;
    let id_sku = parseInt(raw_id_sku);
    if (isNaN(id_sku)) id_sku = null;

    try {
        // ============================================================
        // BƯỚC 2: XÁC MINH GIÁ VÀ SẢN PHẨM TRONG DB
        // ============================================================
        let price = 0;
        let contentName = 'Product';
        let sku = null;

        if (id_sku) {
            const skuRes = await db.query('SELECT * FROM sku WHERE id = $1', [id_sku]);
            sku = skuRes.rows[0];
            if (sku) {
                let rawPrice = sku.price || 0;
                if (typeof rawPrice === 'string') rawPrice = rawPrice.replace(/[^0-9.]/g, '');

                price = parseFloat(rawPrice) || 0;
                contentName = sku.sku_name || 'Product';
            }
        }

        // ============================================================
        // BƯỚC 3: TÍNH TOÁN GIÁ TRỊ CUỐI CÙNG
        // ============================================================
        const quantity = parseInt(reqQty) || 1;
        const finalPrice = price;
        const totalValue = quantity * finalPrice; // Tổng giá trị thực tế

        console.log('[DEBUG COOKIES PURCHASE]', req.cookies); // (Giữ lại để debug nếu cần)

        const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const enrichedUserData = { ...user_data, ip_address: clientIp };

        // ============================================================
        // BƯỚC 4: LƯU LỊCH SỬ MUA HÀNG VÀO DATABASE
        // ============================================================
        const pageUrl = process.env.APP_BASE_URL || 'https://shop01.okban.shop/';
        const referrer = req.headers['referer'] || '';
        const contentId = id_sku ? id_sku.toString() : null;

        const ttclid = req.cookies.ttclid || req.query.ttclid || '';
        const ttp = req.cookies._ttp || '';
        const userAgent = req.headers['user-agent'] || '';

        await db.query(
            `INSERT INTO tiktok_checkout_logs 
          (event_name, event_id, quantity, unit_price, sku_id, user_data, currency, content_category, content_type, page_url, referrer, content_id, ttclid, ttp, user_agent, total_value)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
          ON CONFLICT (event_id) DO NOTHING`,
            ['Purchase', event_id, quantity, finalPrice, id_sku ? id_sku.toString() : null, enrichedUserData, currency || 'VND', content_category || '', content_type || 'product', pageUrl, referrer, contentId, ttclid, ttp, userAgent, totalValue]
        );

        // ============================================================
        // BƯỚC 5: GỬI SỰ KIỆN MUA HÀNG SANG TIKTOK API
        // ============================================================
        tiktokService.sendPurchase(req, {
            order_id: event_id,
            phone: enrichedUserData.phone,
            price: finalPrice,
            quantity: quantity,
            id_sku: id_sku
        });

        res.json({ success: true });

    } catch (err) {
        console.error('[CompletePayment Error]', err);
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.deleteLogs = async (req, res) => {
    const { logIds } = req.body; // Array of IDs
    try {
        if (!logIds || !Array.isArray(logIds) || logIds.length === 0) {
            return res.json({ success: false, message: 'No logs selected' });
        }

        // Use ANY to delete multiple IDs safely
        await db.query('DELETE FROM tiktok_checkout_logs WHERE id = ANY($1::int[])', [logIds]);

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.getTikTokCatalog = async (req, res) => {
    try {
        // 1. Fetch SKUs with Product Info
        const query = `
            SELECT s.*, p.name as product_name, p.image_urls, p.brand, p.material 
            FROM sku s 
            JOIN sanpham p ON s.product_id = p.id 
            ORDER BY s.id ASC
        `;
        const result = await db.query(query);
        const skus = result.rows;

        // 2. Define CSV Headers
        const headers = [
            'sku_id', 'title', 'description', 'availability', 'condition', 'price',
            'link', 'image_link', 'video_link', 'brand', 'additional_image_link',
            'age_group', 'color', 'gender', 'item_group_id', 'google_product_category',
            'material', 'pattern', 'product_type', 'sale_price', 'sale_price_effective_date',
            'shipping', 'shipping_weight', 'gtin', 'mpn', 'size', 'tax',
            'ios_url', 'ios_app_store_id', 'ios_app_name',
            'iPhone_url', 'iPhone_app_store_id', 'iPhone_app_name',
            'iPad_url', 'iPad_app_store_id', 'iPad_app_name',
            'android_url', 'android_package', 'android_app_name',
            'custom_label_0', 'custom_label_1', 'custom_label_2', 'custom_label_3', 'custom_label_4'
        ];

        // 3. Build CSV Rows
        const rows = skus.map(sku => {
            const escape = (text) => {
                if (!text) return '';
                const str = String(text);
                if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                    return `"${str.replace(/"/g, '""')}"`;
                }
                return str;
            };

            const title = `${sku.product_name} - ${sku.sku_name}`;
            const description = sku.description || sku.product_name;
            const availability = 'in stock';
            const condition = 'new';
            const price = `${Number(sku.price).toFixed(2)} ${sku.currency || 'VND'}`;
            const link = `https://shop01.okban.shop/`;

            let imageLink = sku.sku_image_url;
            if (!imageLink && sku.image_urls && sku.image_urls.length > 0) {
                imageLink = sku.image_urls[0];
            }

            let additionalImages = '';
            if (sku.image_urls && sku.image_urls.length > 1) {
                const others = sku.image_urls.filter(img => img !== imageLink);
                if (others.length > 0) {
                    additionalImages = others.slice(0, 10).join(',');
                }
            }

            const brand = sku.brand || 'Okban';
            const material = sku.material || '';
            const googleCategory = sku.content_category || '';

            return [
                escape(sku.id),                     // sku_id
                escape(title),                      // title
                escape(description),                // description
                escape(availability),               // availability
                escape(condition),                  // condition
                escape(price),                      // price
                escape(link),                       // link
                escape(imageLink),                  // image_link
                '',                                 // video_link
                escape(brand),                      // brand
                escape(additionalImages),           // additional_image_link
                '', '', '', '',
                escape(googleCategory),             // google_product_category
                escape(material),                   // material
                '', '', '', '', '', '', '', '', '', '',
                '', '', '', '', '', '', '', '', '', '', '', '',
                '', '', '', '', ''
            ].join(',');
        });

        // 4. Combine Header and Rows
        const csvContent = headers.join(',') + '\n' + rows.join('\n');

        // 5. Send Response
        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="tiktok_catalog.csv"');
        res.send(csvContent);

    } catch (err) {
        console.error('Error generating TikTok Catalog:', err);
        res.status(500).send('Server Error generating catalog');
    }
};
