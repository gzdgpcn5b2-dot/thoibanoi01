const db = require('../config/db');

// Multer setup
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '../../public/images'));
    },
    filename: function (req, file, cb) {
        // Keep original name but prepend timestamp to avoid collision if needed, 
        // OR just keep original name as per user preference likely (simple)
        // User asked to "download from computer to folder", simplest is keep name.
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

exports.uploadImage = [
    upload.array('upload_image', 10), // Allow up to 10 files
    (req, res) => {
        // Redirect back to the referring page
        const backURL = req.header('Referer') || '/cms/sanpham';
        res.redirect(backURL);
    }
];

exports.deleteImage = (req, res) => {
    const imageName = req.body.image_name;
    if (!imageName) return res.status(400).send('Missing image name');

    // Security check: prevent directory traversal
    const safeName = path.basename(imageName);
    const imagePath = path.join(__dirname, '../../public/images', safeName);

    try {
        if (fs.existsSync(imagePath)) {
            fs.unlinkSync(imagePath);
        }
        const backURL = req.header('Referer') || '/cms/sanpham';
        res.redirect(backURL);
    } catch (err) {
        console.error('Delete image error:', err);
        res.status(500).send('Error deleting image');
    }
};

exports.listProducts = async (req, res) => {
    try {
        // Prevent caching for real-time updates
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');

        const productsRes = await db.query('SELECT * FROM sanpham ORDER BY id DESC');
        const products = productsRes.rows;
        // Lấy SKUs cho mỗi sản phẩm
        for (let p of products) {
            const skuRes = await db.query('SELECT * FROM sku WHERE product_id = $1', [p.id]);
            p.skus = skuRes.rows;
        }
        res.render('cms/sanpham', { products });
    } catch (err) {
        console.error(err);
        res.send('Error');
    }
};

exports.editProductPage = async (req, res) => {
    try {
        const productRes = await db.query('SELECT * FROM sanpham WHERE id = $1', [req.params.id]);
        const product = productRes.rows[0];
        if (!product) return res.send('Not found');

        // Prevent Caching
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');

        const skuRes = await db.query('SELECT * FROM sku WHERE product_id = $1', [product.id]);
        product.skus = skuRes.rows;

        // Read images from public/images
        const fs = require('fs');
        const path = require('path');
        const imagesDir = path.join(__dirname, '../../public/images');
        let availableImages = [];
        try {
            if (fs.existsSync(imagesDir)) {
                availableImages = fs.readdirSync(imagesDir).filter(file => /\.(jpg|jpeg|png|gif|webp)$/i.test(file));
                availableImages = availableImages.map(img => '/images/' + img);
            }
        } catch (e) {
            console.error('Error reading images dir:', e);
        }

        res.render('cms/edit', { product, availableImages });
    } catch (err) {
        console.error(err);
        res.send('Error');
    }
};


exports.createProductPage = async (req, res) => {
    // Read images like in edit page
    const fs = require('fs');
    const path = require('path');
    const imagesDir = path.join(__dirname, '../../public/images');
    let availableImages = [];
    try {
        if (fs.existsSync(imagesDir)) {
            availableImages = fs.readdirSync(imagesDir).filter(file => /\.(jpg|jpeg|png|gif|webp)$/i.test(file));
            availableImages = availableImages.map(img => '/images/' + img);
        }
    } catch (e) {
        console.error('Error reading images dir:', e);
    }
    res.render('cms/add', { availableImages });
};

exports.createProduct = async (req, res) => {
    const { name, brand, material, description_sanpham, image_urls } = req.body;
    try {
        let imageUrlsJson = '[]';
        try { imageUrlsJson = image_urls; JSON.parse(imageUrlsJson); } catch (e) { imageUrlsJson = '[]'; }

        const result = await db.query(
            'INSERT INTO sanpham (name, brand, material, description_sanpham, image_urls) VALUES ($1, $2, $3, $4, $5::jsonb) RETURNING id',
            [name, brand, material, description_sanpham, imageUrlsJson]
        );
        const newId = result.rows[0].id;
        // Redirect to edit page to add SKUs
        res.redirect('/cms/sanpham/edit/' + newId);
    } catch (err) {
        console.error(err);
        res.send('Error creating product: ' + err.message);
    }
};

exports.upsertProduct = async (req, res) => {
    const { id, name, brand, material, description_sanpham, image_urls, sku_ids, sku_names, sku_prices, sku_images, sku_descriptions } = req.body;

    const client = await db.pool.connect();

    console.log('[DEBUG] upsertProduct body:', JSON.stringify(req.body, null, 2));

    try {
        await client.query('BEGIN');

        // 1. Update Product
        let imageUrlsJson = '[]';
        try {
            imageUrlsJson = image_urls; // Assume user inputs valid JSON or string
            // Basic validation check if it parses
            JSON.parse(imageUrlsJson);
        } catch (e) {
            console.error("Invalid JSON for images, defaulting to []");
            imageUrlsJson = '[]';
        }

        await client.query(
            'UPDATE sanpham SET name = $1, image_urls = $2::jsonb, brand = $3, material = $4, description_sanpham = $5 WHERE id = $6',
            [name, imageUrlsJson, brand, material, description_sanpham, id]
        );

        // 2. Update SKUs
        // req.body arrays can be single value (string) if only 1 item, or array if multiple.
        // Helper to ensure array
        const toArray = (val) => Array.isArray(val) ? val : [val];

        const ids = toArray(sku_ids || []);
        const names = toArray(sku_names || []);
        const prices = toArray(sku_prices || []);
        const images = toArray(sku_images || []);
        const descs = toArray(sku_descriptions || []);

        for (let i = 0; i < ids.length; i++) {
            await client.query(
                `UPDATE sku 
                  SET sku_name = $1, price = $2, sku_image_url = $3, description = $4 
                  WHERE id = $5`,
                [names[i], prices[i], images[i], descs[i], ids[i]]
            );
        }

        // 3. Delete SKUs
        // deleted_sku_ids might be "101,102" or empty
        if (req.body.deleted_sku_ids) {
            const delIds = req.body.deleted_sku_ids.split(',').filter(x => x).map(x => x.trim());
            for (let dId of delIds) {
                // Security: ensure this SKU belongs to this product? 
                // strictly speaking yes, but for now simple delete by ID is okay for admin.
                await client.query('DELETE FROM sku WHERE id = $1', [dId]);
            }
        }

        // 4. Insert New SKUs
        const newNames = toArray(req.body.new_sku_names || []);
        const newPrices = toArray(req.body.new_sku_prices || []);
        const newImages = toArray(req.body.new_sku_images || []);
        const newDescs = toArray(req.body.new_sku_descriptions || []);

        for (let i = 0; i < newNames.length; i++) {
            if (!newNames[i]) continue; // Skip if name empty
            await client.query(
                `INSERT INTO sku (product_id, sku_name, price, sku_image_url, description) 
                 VALUES ($1, $2, $3, $4, $5)`,
                [id, newNames[i], newPrices[i] || 0, newImages[i] || '', newDescs[i] || '']
            );
        }

        await client.query('COMMIT');
        res.redirect('/cms/sanpham/edit/' + id);
    } catch (err) {
        await client.query('ROLLBACK');
        console.error(err);
        res.status(500).send('Error updating product: ' + err.message);
    } finally {
        client.release();
    }
};

exports.deleteProduct = async (req, res) => {
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');
        // Delete SKUs first (Foreign Key constraint)
        await client.query('DELETE FROM sku WHERE product_id = $1', [req.params.id]);
        // Delete Product
        await client.query('DELETE FROM sanpham WHERE id = $1', [req.params.id]);
        await client.query('COMMIT');
        res.redirect('/cms/sanpham');
    } catch (err) {
        await client.query('ROLLBACK');
        console.error(err);
        res.send('Error deleting: ' + err.message);
    } finally {
        client.release();
    }
};

exports.viewLogs = async (req, res) => {
    try {
        const query = `
            SELECT t.*, s.sku_name as content_name, '${process.env.APP_BASE_URL || 'https://shop01.okban.shop/'}' as url, t.page_url, t.referrer, t.content_id, t.ttclid, t.ttp, t.user_agent 
            FROM tiktok_checkout_logs t
            LEFT JOIN sku s ON t.sku_id::varchar = s.id::varchar
            ORDER BY t.created_at DESC
        `;
        const logs = await db.query(query);
        res.render('cms/logs', { logs: logs.rows });
    } catch (err) {
        console.error(err);
        res.send('Error');
    }
};
