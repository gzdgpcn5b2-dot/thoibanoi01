const axios = require('axios');
const crypto = require('crypto');

// ==========================================
// 1. CẤU HÌNH CỐ ĐỊNH (CONSTANTS)
// ==========================================
const TIKTOK_CONFIG = {
    PIXEL_CODE: process.env.TIKTOK_PIXEL_CODE,
    ACCESS_TOKEN: process.env.TIKTOK_ACCESS_TOKEN,
    API_URL: "https://business-api.tiktok.com/open_api/v1.3/pixel/track/",
    CURRENCY: "VND",
    CONTENT_CATEGORY: "Home Appliances > Kitchen Utensils > Specialized Kitchen Equipment",
    CONTENT_TYPE: "product",
    PAGE_URL: process.env.APP_BASE_URL || "https://shop01.okban.shop/"
};

// ==========================================
// 2. HÀM HỖ TRỢ (HELPER FUNCTIONS)
// ==========================================

function hashPhoneNumber(phone) {
    if (!phone) return null;
    let cleanPhone = phone.toString().replace(/\D/g, '');
    if (cleanPhone.startsWith('0')) {
        cleanPhone = '+84' + cleanPhone.substring(1);
    }
    return crypto.createHash('sha256').update(cleanPhone).digest('hex');
}

async function sendToTikTok(payload) {
    try {
        const response = await axios.post(TIKTOK_CONFIG.API_URL, payload, {
            headers: { 'Access-Token': TIKTOK_CONFIG.ACCESS_TOKEN }
        });
        // console.log(`[TikTok Success] Event: ${payload.event} | Code: ${response.data.code}`);
    } catch (error) {
        console.error(`[TikTok Error]`, error.response ? error.response.data : error.message);
    }
}

// ==========================================
// 3. CODE CHÍNH CHO 2 NÚT
// ==========================================

// --- NÚT 1: InitiateCheckout (Bắt đầu thanh toán) ---
async function sendInitiateCheckout(req, itemData) {
    // 1. Làm sạch & Chuẩn hóa dữ liệu (Data Cleaning)
    let rawPrice = itemData.price ? itemData.price.toString().replace(/\D/g, '') : "0";
    let cleanPrice = Number(rawPrice);
    let cleanQuantity = Number(itemData.quantity) || 1;
    const totalValue = cleanPrice * cleanQuantity; // Tổng giá trị

    // 2. Lấy Tracking ID từ Cookie (Quan trọng cho quảng cáo)
    const ttclid = req.cookies.ttclid || req.query.ttclid;
    const ttp = req.cookies._ttp;

    // 3. Chuẩn bị Payload gửi đi
    let initiateCheckoutPayload = {
        "pixel_code": TIKTOK_CONFIG.PIXEL_CODE,
        "event": "InitiateCheckout",
        "event_id": `IC_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`, // ID sự kiện ngẫu nhiên
        "timestamp": Math.floor(Date.now() / 1000).toString(),
        "context": { // Ngữ cảnh người dùng
            "page": {
                "url": TIKTOK_CONFIG.PAGE_URL,
                "referrer": req.headers['referer'] || ""
            },
            "user_agent": req.headers['user-agent'],
            "ip": req.ip
        },
        "user": { // Định danh người dùng
            "ttclid": ttclid,
            "ttp": ttp
        },
        "properties": { //  Chi tiết sản phẩm
            "currency": TIKTOK_CONFIG.CURRENCY,
            "value": totalValue,
            "content_category": TIKTOK_CONFIG.CONTENT_CATEGORY,
            "content_type": TIKTOK_CONFIG.CONTENT_TYPE,
            "contents": [
                {
                    "content_id": itemData.id_sku || "SKU_MISSING",
                    "content_type": "product",
                    "quantity": cleanQuantity,
                    "price": cleanPrice
                }
            ]
        }
    };

    // 4. Gửi Request
    await sendToTikTok(initiateCheckoutPayload);
}

// --- NÚT 2: Purchase (Hoàn tất mua hàng) ---
async function sendPurchase(req, orderData) {

    // --- BƯỚC 1: LÀM SẠCH DỮ LIỆU ---
    // Kiểm tra SKU ID
    if (!orderData.id_sku || orderData.id_sku.trim() === "") {
        console.warn("⚠️ CẢNH BÁO: Không tìm thấy SKU!");
        orderData.id_sku = "SKU_LOI_MISSING_ID";
    }

    // Làm sạch giá tiền & số lượng
    let rawPrice = orderData.price ? orderData.price.toString().replace(/\D/g, '') : "0";
    let cleanPrice = Number(rawPrice);
    let cleanQuantity = Number(orderData.quantity);
    if (isNaN(cleanQuantity)) cleanQuantity = 1;

    // --- BƯỚC 2: MÃ HÓA THÔNG TIN NGƯỜI DÙNG (BẢO MẬT) ---
    const rawPhone = orderData.phone;
    const hashedPhone = hashPhoneNumber(rawPhone); // SHA256 Hash

    // Tính tổng giá trị
    const totalValue = cleanPrice * cleanQuantity;

    // Lấy Cookie TikTok
    const ttclid = req.cookies.ttclid || req.query.ttclid;
    const ttp = req.cookies._ttp;

    // --- BƯỚC 3: TẠO PAYLOAD PURCHASE ---
    let purchasePayload = {
        "pixel_code": TIKTOK_CONFIG.PIXEL_CODE,
        "event": "Purchase",
        "event_id": orderData.order_id, // ID đơn hàng (chống trùng)
        "timestamp": Math.floor(Date.now() / 1000).toString(),
        "context": {
            "page": {
                "url": TIKTOK_CONFIG.PAGE_URL,
                "referrer": req.headers['referer'] || ""
            },
            "user_agent": req.headers['user-agent'],
            "ip": req.ip
        },
        "user": {
            "phone_number": hashedPhone, // SĐT đã mã hóa
            "external_id": hashedPhone,  // Dùng SĐT làm ID User
            "ttclid": ttclid,
            "ttp": ttp
        },
        "properties": {
            "currency": TIKTOK_CONFIG.CURRENCY,
            "value": totalValue, // Giá trị đơn hàng
            "content_category": TIKTOK_CONFIG.CONTENT_CATEGORY,
            "content_type": TIKTOK_CONFIG.CONTENT_TYPE,
            "contents": [
                {
                    "content_id": orderData.id_sku,
                    "content_type": "product",
                    "quantity": cleanQuantity,
                    "price": cleanPrice
                }
            ]
        }
    };

    // --- BƯỚC 4: GỬI REQUEST ---
    await sendToTikTok(purchasePayload);
}

module.exports = { sendInitiateCheckout, sendPurchase };