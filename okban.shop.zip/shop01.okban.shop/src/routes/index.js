const express = require('express');
const router = express.Router();
const homeController = require('../controllers/homeController');

router.get('/', homeController.index);
router.post('/api/checkout/initiate', homeController.initiateCheckout);
router.post('/api/checkout/complete', homeController.completePayment);
router.get('/tiktok/catalog', homeController.getTikTokCatalog);

module.exports = router;
