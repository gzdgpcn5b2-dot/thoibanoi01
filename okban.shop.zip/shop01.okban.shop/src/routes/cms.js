const express = require('express');
const router = express.Router();
const cmsController = require('../controllers/cmsController');
const homeController = require('../controllers/homeController'); // Import homeController for deleteLogs

router.get('/sanpham', cmsController.listProducts);
router.get('/sanpham/add', cmsController.createProductPage); // Add Page
router.post('/sanpham/add', cmsController.createProduct); // Create Action
router.get('/sanpham/edit/:id', cmsController.editProductPage);
router.post('/sanpham', cmsController.upsertProduct);
router.get('/sanpham/delete/:id', cmsController.deleteProduct);
router.post('/sanpham/delete/:id', cmsController.deleteProduct);

// Image mgmt
router.post('/upload', cmsController.uploadImage);
router.post('/delete-image', cmsController.deleteImage);

router.get('/logs', cmsController.viewLogs);
router.post('/logs/delete', homeController.deleteLogs); // New Date Route

module.exports = router;
