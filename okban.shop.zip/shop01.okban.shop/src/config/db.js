const { Pool } = require('pg');
require('dotenv').config({ override: true });

const pool = new Pool({
    user: process.env.APP_DB_USER,
    host: process.env.APP_DB_HOST,
    database: process.env.APP_DB_NAME,
    password: process.env.APP_DB_PASSWORD,
    port: process.env.APP_DB_PORT,
});

console.log('DEBUG DB CONFIG:', {
    user: process.env.APP_DB_USER,
    host: process.env.APP_DB_HOST,
    database: process.env.APP_DB_NAME,
    password: process.env.APP_DB_PASSWORD ? '***' : 'MISSING',
    port: process.env.APP_DB_PORT,
    cwd: process.cwd(),
    env_file_path: require('path').resolve(process.cwd(), '.env')
});



pool.on('error', (err) => {
    console.error('Unexpected error on idle client', err);
    process.exit(-1);
});

module.exports = {
    query: (text, params) => pool.query(text, params),
    pool: pool
};
