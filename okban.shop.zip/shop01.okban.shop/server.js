const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser'); // Add this
const path = require('path');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Config View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser()); // Add this
app.use(express.static(path.join(__dirname, 'public')));

// Routes
const indexRoutes = require('./src/routes/index');
const cmsRoutes = require('./src/routes/cms');

app.use('/', indexRoutes);
app.use('/cms', cmsRoutes);

// Start Server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
