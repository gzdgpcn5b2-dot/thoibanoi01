# Landing Page Nồi Điện Đa Năng & CMS

Dự án Landing Page bán hàng tích hợp CMS quản lý sản phẩm và theo dõi chuyển đổi TikTok Pixel (Server-Side Events).

## 1. Yêu cầu Hệ Thống (Software & Versions)

-   **Node.js**: Phiên bản 18.x trở lên.
-   **PostgreSQL**: Phiên bản 14.x trở lên.
-   **NPM**: Trình quản lý gói đi kèm Node.js.

### Các thư viện chính (Dependencies):
-   `express` (^4.18.2): Web Server Framework.
-   `pg` (^8.11.3): Driver kết nối PostgreSQL.
-   `ejs` (^3.1.9): View Engine để render giao diện HTML.
-   `dotenv` (^16.3.1): Quản lý biến môi trường (.env).
-   `cookie-parser` (^1.4.7): Xử lý cookie (để đọc TikTok Cookies).
-   `axios` (^1.13.2): Gửi request HTTP (dùng để bắn API sang TikTok).

## 2. Cấu Trúc Thư Mục

```text
/
├── .env                # File cấu hình biến môi trường (Database, API Keys) - RẤT QUAN TRỌNG
├── server.js           # File khởi chạy chính của ứng dụng
├── package.json        # File khai báo thông tin dự án và thư viện
├── public/             # Chứa tệp tĩnh (CSS, JS Client-side, Hình ảnh)
│   ├── css/
│   ├── js/
│   └── images/
├── views/              # Chứa giao diện (Template EJS)
│   ├── pages/          # Giao diện trang bán hàng (Frontend)
│   └── cms/            # Giao diện trang quản trị (Backend)
└── src/
    ├── config/         # Cấu hình kết nối Database (db.js)
    ├── controllers/    # Controller xử lý logic chính (Home, CMS)
    ├── routes/         # Định nghĩa các đường dẫn (URL Route)
    ├── services/       # Các dịch vụ phụ trợ (VD: TikTok API Service)
    └── scripts/        # (Tùy chọn) Các script tiện ích
```

## 3. Hướng Dẫn Cài Đặt (Implementation Guide)

### Bước 1: Cài đặt Phần mềm
Đảm bảo đã cài đặt Node.js và PostgreSQL trên máy chủ.

### Bước 2: Setup Database
1.  **Tạo Database**:
    ```sql
    CREATE DATABASE sql_shop01_db;
    ```
2.  **Tạo Bảng (Schema)**:
    Chạy các câu lệnh SQL sau để tạo bảng sản phẩm (`sanpham`), biến thể (`sku`), và log TikTok (`tiktok_checkout_logs`):
    ```sql
    -- 1. Tạo bảng CHA: Sản phẩm chung (sanpham)
    CREATE TABLE IF NOT EXISTS sanpham (
        id BIGSERIAL PRIMARY KEY,                   -- ID tự tăng (Khóa chính)
        name VARCHAR(255) NOT NULL,                 -- Tên sản phẩm
        image_urls JSONB DEFAULT '[]',              -- Lưu danh sách đường dẫn ảnh (Tối đa 9 ảnh)
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- 2. Tạo bảng CON: Các biến thể (sku)
    CREATE TABLE IF NOT EXISTS sku (
        id BIGSERIAL PRIMARY KEY,                   -- ID tự tăng của SKU
        product_id BIGINT REFERENCES sanpham(id) ON DELETE CASCADE, -- Khóa ngoại
        sku_name VARCHAR(255) NOT NULL,             -- Tên SKU
        sku_image_url VARCHAR(500),                 -- Đường dẫn 1 ảnh đại diện
        price NUMERIC(15, 2) NOT NULL DEFAULT 0,    -- Giá
        currency VARCHAR(10) DEFAULT 'VND',         -- Đơn vị tiền tệ
        content_category VARCHAR(100),              -- Phục vụ TikTok API
        content_type VARCHAR(100) DEFAULT 'product',
        description TEXT,                           -- Mô tả chi tiết
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- 3. Index
    CREATE INDEX IF NOT EXISTS idx_sku_product_id ON sku(product_id);

    -- 4. Logs API
    CREATE TABLE IF NOT EXISTS tiktok_checkout_logs (
        id BIGSERIAL PRIMARY KEY,
        event_name VARCHAR(50) NOT NULL CHECK (event_name IN ('InitiateCheckout', 'CompletePayment')),
        event_id VARCHAR(255) UNIQUE NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        unit_price NUMERIC(15, 2) NOT NULL DEFAULT 0,
        total_value NUMERIC(15, 2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
        currency VARCHAR(10) DEFAULT 'VND',
        content_category VARCHAR(255) DEFAULT 'Thiết bị gia dụng > Dụng cụ nhà bếp > Thiết bị nhà bếp chuyên dụng',
        content_type VARCHAR(50) DEFAULT 'product',
        sku_id VARCHAR(100),
        user_data JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE INDEX IF NOT EXISTS idx_checkout_event_id ON tiktok_checkout_logs(event_id);
    ```

### Bước 3: Cấu hình Môi trường (.env)
Tạo file `.env` tại thư mục gốc với nội dung:

```env
# Database Config
APP_DB_USER=your_db_user
APP_DB_PASSWORD=your_db_password
APP_DB_HOST=localhost
APP_DB_NAME=sql_shop01_db
APP_DB_PORT=5432
PORT=3000

# TikTok API Config
TIKTOK_PIXEL_CODE=YOUR_PIXEL_CODE
TIKTOK_ACCESS_TOKEN=YOUR_ACCESS_TOKEN
APP_BASE_URL=https://yourdomain.com/
```

### Bước 4: Cài đặt và Chạy (Production với PM2)
Để đảm bảo server luôn chạy ổn định và tự động khởi động lại khi có lỗi, chúng ta sử dụng **PM2**.

1.  **Cài đặt thư viện**:
    ```bash
    npm install
    npm install -g pm2  # Cài PM2 global nếu chưa có
    ```
2.  **Khởi động Server**:
    ```bash
    pm2 start server.js --name "landing-shop"
    ```
3.  **Các lệnh PM2 thường dùng**:
    -   Xem trạng thái: `pm2 list`
    -   Khởi động lại (khi sửa code): `pm2 restart landing-shop` hoặc `pm2 restart 0`
    -   Xem log lỗi: `pm2 logs`
    -   Dừng server: `pm2 stop landing-shop`

## 4. Các Lỗi Thường Gặp (Troubleshooting)

### Server không cập nhật code mới
-   **Nguyên nhân**: Do PM2 hoặc tiến trình cũ vẫn đang chạy ngầm.
-   **Khắc phục**: Chạy `pm2 restart all` để ép server chạy code mới nhất.

### Lỗi hiển thị "NaN" hoặc "0 đ"
-   **Nguyên nhân**: Dữ liệu cũ trong database bị thiếu hoặc server chưa tính toán đúng giá.
-   **Khắc phục**: Restart server và đặt đơn hàng mới để kiểm tra.

### Lỗi Database (Connection Refused)
-   **Nguyên nhân**: Sai thông tin trong `.env` hoặc PostgreSQL chưa chạy.
-   **Khắc phục**: Kiểm tra kỹ user/password và đảm bảo service postgresql đang bật (`sudo service postgresql start`).

## 5. Chi tiết Tham số Tracking (Tracking Parameters Dictionary)

Dưới đây là bảng giải thích chi tiết các tham số được gửi đi trong sự kiện TikTok Pixel:

### Sự kiện 1: InitiateCheckout (Bắt đầu thanh toán)
| Tham Số (Parameter) | Ý Nghĩa (Meaning) | Nguồn Dữ Liệu (Source) |
| :--- | :--- | :--- |
| **event** | Tên sự kiện (`InitiateCheckout`) | Cố định (Hardcoded) |
| **event_id** | Mã định danh duy nhất của sự kiện | Tạo tự động (`IC_` + Timestamp + Random) |
| **value** | Tổng giá trị đơn hàng dự kiến | `Quantity` (Số lượng) x `Price` (Đơn giá) |
| **currency** | Đơn vị tiền tệ (`VND`) | Cố định |
| **content_id** | Mã sản phẩm (SKU ID) | Lấy từ Database (Bảng `sku`) dựa trên ID gửi lên |
| **content_type** | Loại nội dung (`product`) | Cố định |
| **ttclid** | TikTok Click ID (Quan trọng để tối ưu quảng cáo) | Lấy từ Cookie `ttclid` (Do TikTok tự sinh khi user click quảng cáo) |
| **ttp** | TikTok Pixel Cookie | Lấy từ Cookie `_ttp` |
| **url** | Đường dẫn trang hiện tại | Cấu hình `APP_BASE_URL` trong `.env` |
| **referrer** | Trang trước đó người dùng truy cập | Lấy từ Header `referer` của trình duyệt |
| **ip** | Địa chỉ IP người dùng | Lấy từ Header `x-forwarded-for` hoặc kết nối socket |
| **user_agent** | Thông tin trình duyệt thiết bị | Lấy từ Header `user-agent` |

### Sự kiện 2: Purchase (Hoàn tất đơn hàng)
| Tham Số (Parameter) | Ý Nghĩa (Meaning) | Nguồn Dữ Liệu (Source) |
| :--- | :--- | :--- |
| **event** | Tên sự kiện (`Purchase`) | Cố định (Hardcoded) |
| **event_id** | Mã đơn hàng duy nhất | **Quan trọng**: Dùng để chống trùng lặp đơn hàng (Deduplication) |
| **value** | Tổng giá trị thực tế thanh toán | `Quantity` x `Price` (Đã được làm sạch và tính toán lại từ server) |
| **phone_number** | Số điện thoại người mua (Đã mã hóa) | Từ Form nhập liệu -> Được mã hóa SHA256 để bảo mật |
| **external_id** | Định danh người dùng (Dùng SĐT mã hóa) | Giống `phone_number`, giúp TikTok nhận diện user |
| **(Các tham số khác)** | `ttclid`, `ttp`, `ip`, `user_agent`... | Tương tự như sự kiện *InitiateCheckout* |

## 6. Luồng Hoạt Động (Page Logic & Workflows)

### A. Trang Chủ (Index Page)
Trang chủ hoạt động với cơ chế **2 Bước trong 1 Popup** (được xử lý tại `#popup1`):

1.  **Bước 1: Chọn Phân Loại (Trigger InitiateCheckout)**
    -   Khi khách hàng bấm **"Mua ngay"**, Popup hiện ra.
    -   Khách chọn màu sắc/size (SKU).
    -   Bấm nút **"Mua ngay"** lần 1:
        -   Hệ thống gọi API `POST /api/checkout/initiate`.
        -   Ghi log sự kiện `InitiateCheckout` vào Database.
        -   Gửi sự kiện sang TikTok Pixel.
        -   **Giao diện**: Form điền thông tin khách hàng sẽ trượt xuống (Expand).

2.  **Bước 2: Điền Thông Tin & Hoàn Tất (Trigger Purchase)**
    -   Khách điền tên, sđt, địa chỉ.
    -   Bấm nút **"Đặt hàng"**:
        -   Hệ thống gọi API `POST /api/checkout/complete`.
        -   Ghi log sự kiện `Purchase` vào Database.
        -   Gửi sự kiện sang TikTok Pixel.
        -   Hiển thị thông báo thành công và tải lại trang.

### B. Trang Quản Trị (CMS Page)
-   **Đường dẫn**: `/cms/logs`
-   **Cơ chế hoạt động**: **Server-Side Rendering (SSR)**.
-   **Cách lấy dữ liệu**:
    1.  Khi Admin truy cập URL, Server sẽ query trực tiếp vào Database PostgreSQL.
    2.  Dữ liệu mới nhất được chèn vào HTML thông qua EJS template engine (`views/cms/logs.ejs`).
    3.  Trang web được trả về trình duyệt với dữ liệu tĩnh.
-   **Cập nhật dữ liệu (Real-time?)**: Hiện tại CMS sử dụng cơ chế **Reload thủ công**. Để xem đơn hàng mới, Admin cần bấm **F5 (Reload)** trang. (Không sử dụng WebSocket hay AJAX polling ngầm để tránh nặng server không cần thiết).

### C. Quản Lý Sản Phẩm (Product CMS)
Hệ thống quản lý sản phẩm bao gồm 2 cấp: **Sản phẩm (Parent)** và **SKU (Child)**.

1.  **Danh Sách Sản Phẩm (`sanpham.ejs`)**
    -   Hiển thị bảng liệt kê Database `sanpham`.
    -   **Các cột hiển thị**:
        -   ID, Tên sản phẩm.
        -   Ảnh mô tả (Hiển thị tối đa 9 ảnh con trong khung).
        -   Mô tả, Chất liệu, Thương hiệu.
        -   Danh sách SKU hiện có (Tên SKU + Ảnh đại diện thu nhỏ).
    -   **Chức năng**:
        -   Có ô đánh dấu (Checkbox) để chọn sản phẩm.
        -   Thanh công cụ bên dưới có 3 tùy chọn: **SỬA - XÓA - THÊM SẢN PHẨM**.

2.  **Thêm Sản Phẩm (`addproduct.ejs`)**
    -   Hiển thị các ô nhập liệu cho bảng `sanpham`.
    -   Sau khi điền thông tin và bấm **LƯU**:
        -   Backend Node.js thực hiện lệnh SQL `INSERT` tạo sản phẩm mới.

3.  **Sửa Sản Phẩm (`edit.ejs`)**
    -   Load dữ liệu hiện tại của sản phẩm vào các ô nhập liệu.
    -   **Quản lý SKU**:
        -   Có nút **THÊM SKU**: Khi ấn sẽ hiện ra một **Popup** (Modal) chứa các tham số cho bảng `sku`.
        -   Popup chỉ đóng khi ấn **Bỏ (Cancel)** hoặc **Lưu (Save)**.
    -   **Lưu Thay Đổi**:
        -   Nút **LƯU** ở dưới cùng sẽ gửi dữ liệu về Backend.
        -   Backend thực hiện lệnh SQL `UPDATE` cho sản phẩm và `INSERT/UPDATE/DELETE` cho các SKU biến thể.

4.  **Xóa Sản Phẩm (`delete` Action)**
    -   Sử dụng lệnh SQL `DELETE` để xóa sản phẩm và các SKU liên quan khỏi Database.
